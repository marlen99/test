from sys import *
from queue import *
from math import *
from random import *

def test(nv, ne):
	e = {}
	vfrom = 0
	for i in range(0, ne):
		vto = randint(0, nv-1)
		while vto == vfrom:
			vto = randint(0, nv-1)
		vfrom = str(vfrom)
		cost = random()*100
		if vfrom not in e:
			e[vfrom] = []
		while 1:
			for i in e[vfrom]:
				if i[1] == vto:
					vto = randint(0, nv-1)
					continue
			break
		e[vfrom].append([cost, str(vto)])
		vfrom = randint(0, nv-1)
	'''keys = list(map(int, e.keys()))
	keys.sort()
	keys = list(map(str, keys))
	for i in keys:
		print(i, *e[i])
	print(keys)'''
	return A_star('0', str(nv-1), e)
		
def A_star(vfrom, vto, e):
	queue = PriorityQueue()
	for i in e[vfrom]:
		queue.put((i[0] + abs(int(vto) - int(i[1])), i[1], vfrom+' '+i[1]))
	cur = queue.get()
	oper = 0
	while cur[1] != vto and queue.qsize() != 0:
		if cur[1] not in e:
			cur = queue.get()
			continue
		for i in e[cur[1]]:
			oper += 1
			if i[1] in cur[2]:
				continue
			queue.put((cur[0]+i[0]-abs(int(vto) - int(cur[1]))+abs(int(vto) - int(i[1])), i[1], cur[2]+' '+i[1]))
		cur = queue.get()
		oper += 1
	if queue.qsize() == 0:
		return (None, oper)
	return (cur[2], oper)


def main():
	f = open('sas', 'a')
	ne, ntimes = map(int, input().split())
	sum = 0
	k = 0
	while k != ntimes:
		ans = test(30, ne)
		if ans[0] is None:
			continue
		lenght = 0
		for c in ans[0]:
			if c == ' ':
				lenght += 1
		if lenght != 5:
			continue
		sum += ans[1]
		print(ans[1], file=f)
		print(k)
		k += 1
	print(ne, sum//ntimes, file=f)

if __name__ == '__main__':
	main()
