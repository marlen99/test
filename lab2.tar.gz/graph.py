import matplotlib.pyplot as plt
import os
import sys

def main(filepath):
	fd = open(filepath, 'r')
	data = []
	for line in fd:
		entry = line.split()
		data.append((int(entry[0]), int(entry[1])))
	data.sort()
	new_data = []
	cur = data[0][0]
	sum = data[0][1]
	count = 1
	for i in range(0, len(data)):
		if data[i][0] == cur:
			sum += data[i][1]
			count += 1
		else:
			new_data.append((cur, sum//count))
			sum = data[i][1]
			cur = data[i][0]
			count = 1
	new_data.append((cur, sum//count))
	x = [i[0] for i in new_data]
	y = [i[1] for i in new_data]
	plt.plot(x, y, label='A*')
	plt.title("Finding way in graph")
	plt.xlabel("||V||*||V||*log(||E||)")
	plt.ylabel('number of processed pathes')
	plt.legend()
	plt.show()

if __name__ == '__main__':
	if len(sys.argv) < 2:
		print("Use 'python {} filepath'".format(sys.argv[0]))
		exit()
	main(sys.argv[1])
