from sys import *

def greedy(vfrom, vto, e):
	if vfrom == vto:
		return vto
	if vfrom not in e:
		return None
	e[vfrom].sort()
	for i in e[vfrom]:
		res = greedy(i[1], vto, e)
		if res is not None:
			return vfrom + res


def main():
	e = {}
	s = input().split()
	for i in stdin:
		i = i.split()
		if i[0] not in e:
			e[i[0]] = []
		e[i[0]].append((float(i[2]), i[1]))
	print(greedy(*s, e))

if __name__ == '__main__':
	main()
