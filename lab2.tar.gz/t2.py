from sys import *


def A_star(vfrom, vto, e):
	def compare(a):
		return ord(vto)-ord(a[1])+a[0]
	queue = []
	for i in e[vfrom]:
		queue.append([*i, vfrom+i[1]])
	queue.sort(key=compare)
	while queue[0][1] != vto:
		if queue[0][1] not in e:
			queue.pop(0)
			continue
		for i in e[queue[0][1]]:
			queue.append([queue[0][0]+i[0], i[1], queue[0][2]+i[1]])
		queue.pop(0)
		queue.sort(key=compare)
	return queue[0][2]


def main():
	e = {}
	s = input().split()
	for i in stdin:
		i = i.split()
		if i[0] not in e:
			e[i[0]] = []
		e[i[0]].append((float(i[2]), i[1]))
	print(A_star(*s, e))

if __name__ == '__main__':
	main()
