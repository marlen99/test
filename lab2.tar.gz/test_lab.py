from sys import *
from queue import *
from math import *
from random import *

def test(nv, ne):
	e = {}
	vfrom = 0
	for i in range(0, ne):
		vto = randint(0, nv-1)
		while vto == vfrom:
			vto = randint(0, nv-1)
		vfrom = str(vfrom)
		cost = random()*100
		if vfrom not in e:
			e[vfrom] = []
		while 1:
			for i in e[vfrom]:
				if i[1] == vto:
					vto = randint(0, nv-1)
					continue
			break
		e[vfrom].append([cost, str(vto)])
		vfrom = randint(0, nv-1)
	'''keys = list(map(int, e.keys()))
	keys.sort()
	keys = list(map(str, keys))
	for i in keys:
		print(i, *e[i])
	print(keys)'''
	return A_star('0', str(nv-1), e)
		
def A_star(vfrom, vto, e):
	def evristic(x):
		for i in range(0, len(v)):
			if x == v[i]:
				x_i = i
			if vto == v[i]:
				vto_i = i
		return ((vto_i - x_i) / len(v)) * min_edge
	v = [i for i in e]
	for i in e:
		for j in e[i]:
			if j[1] not in v:
				v.append(j[1])
	if vto not in v:
		return (None, 0)
	v.sort(key=int)
	min_edge = 0
	for i in e:
		for j in e[i]:
			if j[1] == vto and (j[0] < min_edge or min_edge == 0):
				min_edge = j[0]
	queue = PriorityQueue()
	for i in e[vfrom]:
		queue.put((i[0] + evristic(i[1]), i[1], vfrom+' '+i[1]))
	cur = queue.get()
	oper = 0
	while cur[1] != vto and queue.qsize() != 0:
		if cur[1] not in e:
			cur = queue.get()
			continue
		for i in e[cur[1]]:
			oper += 1
			if i[1] in cur[2]:
				continue
			queue.put((cur[0] + i[0] - evristic(cur[1]) + evristic(i[1]), i[1], cur[2] + ' ' + i[1]))
		cur = queue.get()
		oper += 1
	if queue.qsize() == 0:
		return (None, oper)
	return (cur[2], oper)


def main():
	f = open('stat', 'a')
	i, j, k_max = list(map(int, input().split()))
	sum = 0
	for k in range(0, k_max):
		sum += test(i, j)[1]
	print(int(i*i*log(j, 2).real), sum//k_max, file=f)

if __name__ == '__main__':
	main()
